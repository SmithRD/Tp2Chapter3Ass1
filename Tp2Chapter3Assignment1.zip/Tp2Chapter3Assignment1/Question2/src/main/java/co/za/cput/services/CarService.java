package co.za.cput.services;

import co.za.cput.domain.CarData;

/**
 *
 */
public interface CarService {

    CarData getCarData();
}
